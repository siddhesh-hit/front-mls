import React  from "react";
  
import HeaderEng from "../Components/Common/HeaderEng";
import FooterEng from "../Components/Common/FooterEng";
import VidhanParishad from "../assets/_MG_5358 1.jpg";
import VidhanSabha from "../assets/_MG_5358 2.jpg";
import VidhanBhavan from "../assets/1006 1.jpg";
import homevidhan from "../assets/_MG_5418 1.jpg";
import news1 from "../assets/Link → 1-1-560x379.jpg.jpg";
import news2 from "../assets/Link → 2-1-560x379.jpg.jpg";
import news3 from "../assets/Link → 3-1-560x379.jpg.png";
import { Button, Col, Container, Row } from "react-bootstrap";
import { useState } from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";

const HomePageEng = () => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const galleryItems = document.querySelectorAll(".gallery-item");

    

    function prevSlide() {
        setCurrentSlide(currentSlide - 1);
    }

    function nextSlide() {
        setCurrentSlide(currentSlide + 1);
    }

  return (
    <>
      <div>
        <HeaderEng />
        <section>
          <div className="Page-home">
            <div
              className="container-fluid"
              style={{
                paddingTop: "15%",
              }}
            >
              <div className="home-container">
                <Row>
                  <Col
                    className="lg={3} md={3} sm={12} xs={12} leftside-block d-flex  justify-content-center align-items-center"
                    style={{ marginBottom: "5%" }}
                  >
                    <div className="block-infoleft">
                      <img src={VidhanParishad} alt="" />
                      <div className="text-block">
                        <b>Vidhan Parishad</b>
                        <hr
                          style={{
                            width: "50%",
                            border: "none",
                            height: "3px",
                            background:
                              "linear-gradient(to right, green, yellow)",
                            opacity: "1",
                          }}
                        />
                        <div className="info" style={{ color: "black" }}>
                          The Maharashtra Vidhan Sabha or the Maharashtra
                          Legislative Assembly is the lower house of the
                          legislature of the Indian state of Maharashtra. It is
                          situated in the Nariman Point area of South Mumbai in
                          the capital Mumbai. The Maharashtra Assembly is the
                          lower house of the legislature of the Indian
                          stateAssembly is the lower house
                          <div style={{ marginTop: "3%" }}>
                            <a>
                              <b
                                style={{
                                  fontSize: "15px",
                                  color: "blue",
                                  fontFamily: "Poppins",
                                }}
                              >
                                <a href="" style={{ textDecoration: "none" }}>
                                  Read More{" "}
                                  <i className="fa fa-chevron-right "></i>
                                  <i className="fa fa-chevron-right "></i>
                                </a>
                              </b>
                              <i
                                class="fa-solid fa-chevrons-right"
                                style={{ color: " #e11305" }}
                              ></i>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Col>
                  <Col className="lg={6} md={6} sm={12} xs={12} d-flex justify-content-center align-items-center">
                    <div>
                      <img
                        src={VidhanBhavan}
                        alt=""
                        style={{ marginTop: "-12%" }}
                      />
                    </div>
                  </Col>
                  <Col
                    className="lg={3} md={3} sm={12} xs={12} rightside-block d-flex justify-content-center align-items-center"
                    style={{ marginBottom: "5%" }}
                  >
                    <div className="block-inforight">
                      <img src={VidhanSabha} alt="" />
                      <div className="text-block">
                        <b>Vidhan Sabha</b>
                        <hr
                          style={{
                            width: "50%",
                            border: "none",
                            height: "3px",
                            background:
                              "linear-gradient(to right, green, #FAD02C)",
                            opacity: "1",
                          }}
                        />
                        <div className="info">
                          The Maharashtra Vidhan Sabha or the Maharashtra
                          Legislative Assembly is the lower house of the
                          legislature of the Indian state of Maharashtra. It is
                          situated in the Nariman Point area of South Mumbai in
                          the capital Mumbai. The Maharashtra Assembly is the
                          lower house of the legislature of the Indian
                          stateAssembly is the lower house of the legislature of
                          the Indian state
                          <div style={{ marginTop: "3%" }}>
                            <b
                              style={{
                                fontSize: "15px",
                                color: "blue",
                                fontFamily: "Poppins",
                              }}
                            >
                              <a href="#" style={{ textDecoration: "none" }}>
                                Read More{" "}
                                <i className="fa fa-chevron-right "></i>
                                <i className="fa fa-chevron-right "></i>
                              </a>
                            </b>
                            <i
                              class="fa-solid fa-chevrons-right"
                              style={{ color: " #e11305" }}
                            ></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </section>
        <section>
          <Container>
            <Row>
              <Col className="lg={6} md={6} sm={12} xs={12} d-flex justify-content-center ">
                <img src={homevidhan} alt="" style={{ width: "100%" }} />
              </Col>

              <Col className="lg={6} md={6} sm={12} xs={12} d-flex justify-content-center align-items-center">
                <div className="topic-info text-center">
                  <div className="section-title  d-flex justify-content-center align-items-center">
                    <b>
                      About MLS
                      <hr
                        className="justify-content-center align-items-center"
                        style={{
                          width: "100%",
                          border: "none",
                          height: "3px",
                          background:
                            "linear-gradient(to right, green, #FAD02C)",
                          opacity: "1",
                        }}
                      />
                    </b>
                  </div>
                  <div className="info-about" style={{ fontSize: "14px" }}>
                    The Maharashtra Vidhan Sabha or the Maharashtra Legislative
                    Assembly is the lower house of the legislature of the Indian
                    state of Maharashtra. It is situated in the Nariman Point
                    area of South Mumbai in the capital Mumbai. The Maharashtra
                    Assembly is the lower house of the legislature of the Indian
                    stateAssembly is the lower house of the legislature of the
                    Indian state The Maharashtra Vidhan Sabha or the Maharashtra
                    Legislative Assembly is the lower house of the legislature
                    of the Indian state of Maharashtra. It is situated in the
                    Nariman Point area of South Mumbai in the capital Mumbai.
                    The Maharashtra Assembly is the lower house of the
                    legislature of the Indian stateAssembly is the lower house
                    of the legislature of the Indian state
                  </div>
                  <Link
                    class="btn btn-primary"
                    to="/AboutusEng"
                    style={{
                      backgroundColor: "#000088",
                      marginTop: "5%",
                      textDecoration: "none",
                    }}
                  >
                    Read More
                    <i className="fa fa-chevron-right m-1"></i>{" "}
                    <i className="fa fa-chevron-right "></i>
                  </Link>
                </div>
              </Col>
            </Row>
          </Container>
        </section>

        <section>
          <div
            className="photo-galleryhome  mt-5 mb-5"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
            }}
          >
            <div className="section-head text-center mt-3">
              Photo and video gallery
            </div>
            <hr
              style={{
                width: "20%",
                border: "none",
                height: "3px",
                opacity: "1",
                background: "linear-gradient(to right, green, #FAD02C)",
              }}
            />
            <Container className="photo-video-container mb-5 ">
              <div class="gallery-container">
                <a>
                  <i
                    className="fa fa-chevron-left m-3 justify-content-start"
                    onClick={prevSlide}
                  ></i>
                </a>
                <a>
                  <i
                    class="fa fa-chevron-right m-3 justify-content-end"
                    onClick={nextSlide}
                  ></i>
                </a>

                <div class="gallery">
                  <div class="media">
                    <img src="photo1.jpg" alt="Photo 1" />
                  </div>
                  <div class="media">
                    <img src="photo2.jpg" alt="Photo 2" />
                  </div>
                  <div class="media">
                    <a>
                      <video controls>
                        <source src="video.mp4" type="video/mp4" />
                        <i class="fal fa-search"></i>
                      </video>
                    </a>
                  </div>
                  <div class="media">
                    <img src="photo1.jpg" alt="Photo 1" />
                  </div>
                  <div class="media">
                    <img src="photo1.jpg" alt="Photo 1" />
                  </div>
                  <div class="media">
                    <img src="photo1.jpg" alt="Photo 1" />
                  </div>
                  <div class="media">
                    <video controls>
                      <source src="video.mp4" type="video/mp4" />
                    </video>
                  </div>
                  <div class="media">
                    <video controls>
                      <source src="video.mp4" type="video/mp4" />
                    </video>
                  </div>
                  <div class="media">
                    <img src="photo1.jpg" alt="Photo 1" />
                  </div>
                </div>
              </div>
            </Container>
          </div>
        </section>

        <section className="mt-4">
          <Container>
            <Row>
              <Col className="lg={3} md={3} sm={12} xs={12}">
                <div className="head-news">Latest Update</div>
                <hr
                  style={{
                    width: "50%",
                    border: "1px",
                    height: "3px",
                    opacity: "1",
                    background: "linear-gradient(to right,#008000, #FAD02C)",
                  }}
                />
                <div style={{ color: "#62718D" }}>
                  The Update about recent activities for needed peoples.
                </div>
                <div>
                  <Button
                    className="Button-Morenews"
                    style={{
                      width: "max-content",
                      backgroundColor: "white",
                      border: "1px solid #0067DA",
                      color: "#0067DA",
                      fontSize: "14px",
                      fontFamily: "Poppins",
                    }}
                  >
                    <a style={{ textDecoration: "none" }}>
                      More News <i className="fa fa-chevron-right "></i>
                      <i className="fa fa-chevron-right "></i>
                    </a>
                  </Button>
                </div>
              </Col>
              <Col className="lg={3} md={3} sm={12} xs={12} d-flex justify-cntent-center">
                <div className="news-box">
                  <img src={news1} alt="img" style={{ width: "100%" }} />

                  <div className="date-box">July 24, 2020</div>
                  <div style={{ padding: "3%" }}>
                    <div style={{ color: "#62718D", fontSize: "18px" }}>
                      In City News‚ Community
                      <span>
                        <i class="fa-regular fa-message"></i>
                      </span>
                      <div>Comment off</div>
                    </div>

                    <div style={{ padding: "2%" }}>
                      The new legislature will stand like a new parliament
                      building; Assembly Speaker will propose
                    </div>

                    <div style={{ marginTop: "3%" }}>
                      <a href="#" style={{ textDecoration: "none" }}>
                        <b style={{ fontSize: "15px", color: "blue" }}>
                          Continue Reading
                          <i className="fa fa-chevron-right "></i>
                          <i className="fa fa-chevron-right "></i>
                        </b>
                        <i
                          className="fa-solid fa-chevrons-right"
                          style={{ color: " #e11305" }}
                        ></i>
                      </a>
                    </div>
                  </div>
                </div>
              </Col>
              <Col className="lg={3} md={3} sm={12} xs={12} d-flex justify-cntent-center">
                <div className="news-box">
                  <img src={news2} alt="img" style={{ width: "100%" }} />

                  <div className="date-box">July 24, 2020</div>
                  <div style={{ padding: "3%" }}>
                    <div style={{ color: "#62718D", fontSize: "18px" }}>
                      In Devlopement
                      <span>
                        <i class="fa-regular fa-message"></i>
                      </span>
                      <div>Comment off</div>
                    </div>

                    <div style={{ padding: "2%" }}>
                      The new legislature will stand like a new parliament
                      building; Assembly Speaker will propose
                    </div>

                    <div style={{ marginTop: "3%" }}>
                      <a href="#" style={{ textDecoration: "none" }}>
                        <b style={{ fontSize: "15px", color: "blue" }}>
                          Continue Reading
                          <i className="fa fa-chevron-right "></i>
                          <i className="fa fa-chevron-right "></i>
                        </b>
                        <i
                          className="fa-solid fa-chevrons-right"
                          style={{ color: " #e11305" }}
                        ></i>
                      </a>
                    </div>
                  </div>
                </div>
              </Col>
              <Col className="lg={3} md={3} sm={12} xs={12}">
                <div className="news-box">
                  <img src={news3} alt="img" style={{ width: "100%" }} />

                  <div className="date-box">July 24, 2020</div>
                  <div style={{ padding: "3%" }}>
                    <div style={{ color: "#62718D", fontSize: "18px" }}>
                      In Devlopement
                      <span>
                        <i class="fa-regular fa-message"></i>
                      </span>
                      <div>Comment off</div>
                    </div>

                    <div style={{ padding: "2%" }}>
                      The new legislature will stand like a new parliament
                      building; Assembly Speaker will propose
                    </div>

                    <div style={{ marginTop: "3%" }}>
                      <a href="#" style={{ textDecoration: "none" }}>
                        <b style={{ fontSize: "15px", color: "blue" }}>
                          Continue Reading
                          <i className="fa fa-chevron-right "></i>
                          <i className="fa fa-chevron-right "></i>
                        </b>
                        <i
                          className="fa-solid fa-chevrons-right"
                          style={{ color: " #e11305" }}
                        ></i>
                      </a>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </section>

        <section>
          <div
            className="container block-faq"
            style={{
              paddingTop: "2%",
              paddingBottom: "2%",
              marginBottom: "1%",
            }}
          >
            <div className="col-lg-11">
              <div className="section-faq-head d-flex justify-cntent-center">
                Frequently Asked Questions
              </div>
              <div className="block1">
                <div>
                  <a href="" style={{ textDecoration: "none" }}>
                    What powers does the CAG have to perform his role?
                  </a>
                </div>
              </div>
              <div className="block1" style={{ textDecoration: "none" }}>
                <div>
                  <a href="" style={{ textDecoration: "none" }}>
                    What are the modes of participation?
                  </a>
                </div>
                <div className="block-ans">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry Lorem Ipsum is simply dummy text of the
                  printing and typesetting industry Lorem Ipsum is simply dummy
                  text of the printing and typesetting industry
                </div>
              </div>
              <div className="block1">
                <div>
                  <a href="" style={{ textDecoration: "none" }}>
                    What powers does the CAG have to perform his role?
                  </a>
                </div>
              </div>
              <div className="block1">
                <div>
                  <a href="" style={{ textDecoration: "none" }}>
                    What are the modes of participation?
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* Link section */}

        <section>
          <div className="block-link container mb-5 mt-5 pt-3 pb-3 ">
            <div className="container-fluid justify-content-center">
              <div>
                <div>
                  <button className=" col-lg-2 link-Btn">
                    <a>http://mls.org.in/</a>
                  </button>
                  <button className=" col-lg-2 link-Btn">
                    <a>https://gr.maharashtra.gov.in</a>
                  </button>
                  <button className="col-lg-2 link-Btn">
                    <a>https://gr.maharashtra.gov.in</a>
                  </button>
                  <button className="col-lg-2 link-Btn">
                    <a>https://gr.maharashtra.gov.in</a>
                  </button>
                </div>
                <div className="text-center">
                  <button className="col-lg-2 link-Btn">
                    <a>https://directorate.marathi.gov.in</a>
                  </button>
                  <button className="col-lg-2 link-Btn">
                    <a>https://eci.gov.in/</a>
                  </button>
                  <button className="col-lg-2 link-Btn">
                    <a>https://main.sci.govin/</a>
                  </button>
                </div>

                <div className="mt-3 text-center mb-3">
                  <Link to="/Link-section" style={{ textDecoration: "none" }}>
                    <b style={{ fontSize: "15px", color: "blue" }}>View More</b>
                    <i
                      className="fa fa-chevron-right "
                      style={{ color: "blue" }}
                    ></i>
                    <i
                      className="fa fa-chevron-right "
                      style={{ color: "blue" }}
                    ></i>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <FooterEng />
    </>
  );
};
export default HomePageEng;
